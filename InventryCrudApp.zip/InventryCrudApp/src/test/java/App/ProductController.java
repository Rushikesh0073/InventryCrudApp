package App;

import serviceimplementation.ProductImplementation;

// com.Bean
public class ProductController {

        ProductImplementation pml = new ProductImplementation();

        public  ProductController() {
        }
    }

