package DAO;
    public interface InventoryManagement {
        void addProduct();

        void removeProduct();

        void updateInventory();

        void displayInventory();

        void disaplayTotalValue();

        void searchName();

        void searchCategory();
    }


